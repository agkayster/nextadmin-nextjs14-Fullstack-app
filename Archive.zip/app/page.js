import Image from 'next/image';

export default function Home() {
	return (
		<main className='p-6'>
			<h1>Home page</h1>
		</main>
	);
}